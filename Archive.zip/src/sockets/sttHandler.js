const sttSession = require('../stt/sttSession');
const aiSession = require('../ai/aiSession');

/**
 * Wired to the real "Add AI Assistant" button in `CallScreen` as of Day 16
 * (previously only reachable via `backend/src/spikes/sttLiveSpike.js`).
 * `stt:start` now also opens this room's `aiSession` — capture (STT) and
 * the AI session (transcript accumulation) are separate concerns but share
 * the same trigger, since PROJECT.md's design has "Add AI Assistant" mean
 * both at once.
 *
 *   client -> server  "stt:start"  ()  -> { started: true }
 *   client -> server  "stt:stop"   ()  -> { stopped: true }
 *   client -> server  "ai:status:query" ()  -> { active: boolean }  (for a peer
 *                                               joining mid-call, to sync the
 *                                               AI Assistant toggle/tile without
 *                                               waiting for the next broadcast)
 *   server -> room      "ai:status"  { active: boolean }  (whole room, including
 *                                      the peer who toggled it — "Add AI
 *                                      Assistant" is a meeting-wide switch, not
 *                                      a per-device one, so everyone's UI must
 *                                      reflect the same state)
 *   server -> room     "transcript:segment"  { peerId, displayName, text, at }
 */
function attachStt(io) {
  sttSession.setIo(io);

  io.on('connection', (socket) => {
    socket.on('stt:start', async (_data, callback) => {
      try {
        const roomId = socket.data.roomId;
        if (!roomId) return callback?.({ error: 'Not in a room' });

        aiSession.start(roomId);
        await sttSession.startForRoom(roomId);
        io.to(roomId).emit('ai:status', { active: true });
        callback?.({ started: true });
      } catch (error) {
        callback?.({ error: error.message });
      }
    });

    socket.on('stt:stop', (_data, callback) => {
      const roomId = socket.data.roomId;
      if (!roomId) return callback?.({ error: 'Not in a room' });

      sttSession.stopForRoom(roomId);
      io.to(roomId).emit('ai:status', { active: false });
      callback?.({ stopped: true });
    });

    socket.on('ai:status:query', (_data, callback) => {
      const roomId = socket.data.roomId;
      callback?.({ active: roomId ? sttSession.isActiveForRoom(roomId) : false });
    });
  });
}

module.exports = { attachStt };
