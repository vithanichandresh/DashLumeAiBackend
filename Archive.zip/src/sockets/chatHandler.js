const { admin } = require('../config/firebaseAdmin');
const aiSession = require('../ai/aiSession');
const geminiOrchestrator = require('../ai/geminiOrchestrator');

// Fixed sender identity for AI-generated messages. `senderUid: null` never
// equals a real Firebase uid, so every client's `isMine` check (which
// compares against `FirebaseAuth.currentUser?.uid`) correctly renders it
// as not-mine for everyone — see the 2026-07-06 LESSONS.md chat entry on
// why `isMine` compares uid, not the ephemeral `senderId`.
const AI_SENDER_ID = 'ai-assistant';
const AI_SENDER_NAME = 'AI Assistant';

/**
 * In-call text chat — piggybacks on the Socket.IO room a client already
 * joined via `room:join` in signalingHandler.js (same connection, same
 * room, no separate join handshake). Chat is therefore only available
 * while a call is active, matching the "in-call text chat" scope in
 * PROJECT.md.
 *
 *   client -> server  "chat:message"  { text }
 *   server -> room     "chat:message"  { id, senderId, senderName, text, sentAt }
 *
 * Broadcast goes to the whole room including the sender (`io.to`, not
 * `socket.to`) — the server is the single source of truth for the
 * message list, the client doesn't locally echo its own sends.
 *
 * Also persisted to Firestore at `meetings/{roomId}/messages/{id}` so chat
 * history survives past the live socket session (e.g. a late joiner, or a
 * future meeting-history screen). The realtime path (Socket.IO) and the
 * durable path (Firestore) are independent — a Firestore write failure
 * logs but never blocks/breaks the live broadcast.
 *
 * Day 17: while an AI session is active for the room (`aiSession.hasSession`,
 * toggled by "Add AI Assistant"), every chat message also triggers a
 * Gemini response — grounded in the rolling transcript context
 * (`ai/contextManager.js`) — broadcast back into the same chat as a second
 * message from a fixed "AI Assistant" sender. Runs after the human
 * message is already broadcast/persisted, and never blocks it — a slow or
 * failed Gemini call only delays/drops the AI's own reply, not the
 * person's original message.
 */
function attachChat(io) {
  io.on('connection', (socket) => {
    socket.on('chat:message', ({ text }) => {
      const roomId = socket.data.roomId;
      if (!roomId || !text || !text.trim()) return;

      const trimmedText = text.trim();
      const message = {
        id: `${socket.id}-${Date.now()}`,
        senderId: socket.id,
        // Firebase uid — stable across reconnects/sessions, unlike
        // senderId (socket.id). Used client-side to decide "is this my
        // own message" for historical messages loaded before the current
        // socket has (re)connected.
        senderUid: socket.data.uid,
        senderName: socket.data.displayName || 'Guest',
        text: trimmedText,
        sentAt: new Date().toISOString(),
      };

      broadcastAndPersist(io, roomId, message);

      if (aiSession.hasSession(roomId)) {
        respondAsAi(io, roomId, trimmedText);
      }
    });
  });
}

function broadcastAndPersist(io, roomId, message) {
  io.to(roomId).emit('chat:message', message);

  admin
    .firestore()
    .collection('meetings')
    .doc(roomId)
    .collection('messages')
    .doc(message.id)
    .set(message)
    .catch((error) => console.error(`Failed to persist chat message ${message.id}:`, error));
}

async function respondAsAi(io, roomId, message) {
  let text;
  try {
    text = await geminiOrchestrator.generateResponse(roomId, message);
  } catch (error) {
    console.error(`[AI][${roomId}] Gemini orchestration failed:`, error.message);
    text = "Sorry, I couldn't come up with a response just now.";
  }

  // The room may have ended while the Gemini call was in flight (it's the
  // only genuinely slow step in this whole path) — broadcasting into a
  // room nobody's in anymore is harmless (Socket.IO no-ops), but skip the
  // Firestore write since there's nothing meaningful to attach it to.
  if (!aiSession.hasSession(roomId)) return;

  broadcastAndPersist(io, roomId, {
    id: `${AI_SENDER_ID}-${Date.now()}`,
    senderId: AI_SENDER_ID,
    senderUid: null,
    senderName: AI_SENDER_NAME,
    text,
    sentAt: new Date().toISOString(),
  });
}

module.exports = { attachChat };
