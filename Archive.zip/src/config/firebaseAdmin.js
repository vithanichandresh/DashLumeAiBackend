const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');
const env = require('./env');

function loadServiceAccount() {
  const resolvedPath = path.resolve(process.cwd(), env.firebaseServiceAccountPath);

  if (!fs.existsSync(resolvedPath)) {
    throw new Error(
      `Firebase service account file not found at ${resolvedPath}.\n` +
        'Generate one in the Firebase console: Project Settings > Service Accounts > ' +
        'Generate new private key (project "callmetaai"), save it at that path, and ' +
        'set FIREBASE_SERVICE_ACCOUNT_PATH in backend/.env if you used a different path.'
    );
  }

  return JSON.parse(fs.readFileSync(resolvedPath, 'utf8'));
}

let initialized = false;

function initFirebaseAdmin() {
  if (initialized) return admin;

  const serviceAccount = loadServiceAccount();
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
  initialized = true;
  return admin;
}

module.exports = { initFirebaseAdmin, admin };
