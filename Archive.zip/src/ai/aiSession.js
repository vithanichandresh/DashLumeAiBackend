/**
 * Day 16: AI session lifecycle + transcript accumulation, per meeting.
 *
 * A session exists only once "Add AI Assistant" has been triggered for a
 * room (`stt:start`) — this is the "AI session is created per-meeting on
 * the backend... it is not always-on" behavior from PROJECT.md's AI
 * workflow. Finalized Deepgram segments (see `stt/sttSession.js`) are
 * appended here as they arrive, with speaker attribution.
 *
 * Deliberately scoped to *this* meeting's lifetime, not to STT being
 * toggled on/off mid-call — `start()` is idempotent (a second `stt:start`
 * after a `stt:stop` keeps the existing transcript instead of wiping it),
 * and the session is only cleared when the room itself ends
 * (`signalingHandler.js`'s `endCurrentRoom`/`leaveCurrentRoom`).
 *
 * In-memory only, same posture as `roomManager`/`sfuRoomState` — no
 * persistence yet. Day 17 reads `getTranscript()` for its rolling context
 * window; Day 19 is where a final transcript gets stored (Firestore).
 */

/** @type {Map<string, { startedAt: number, segments: Array<{peerId: string, displayName: string, text: string, at: number}> }>} */
const sessions = new Map();

function start(roomId) {
  if (sessions.has(roomId)) return;
  sessions.set(roomId, { startedAt: Date.now(), segments: [] });
}

function addSegment(roomId, { peerId, displayName, text }) {
  const session = sessions.get(roomId);
  if (!session) return; // stt:start was never called for this room — nothing to accumulate into
  session.segments.push({ peerId, displayName, text, at: Date.now() });
}

function getTranscript(roomId) {
  return sessions.get(roomId)?.segments ?? [];
}

function hasSession(roomId) {
  return sessions.has(roomId);
}

function clearRoom(roomId) {
  sessions.delete(roomId);
}

module.exports = { start, addSegment, getTranscript, hasSession, clearRoom };
