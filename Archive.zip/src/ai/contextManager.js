/**
 * Day 17: rolling transcript context window, built on top of Day 16's
 * `aiSession` (which keeps the *full* accumulated transcript for the
 * meeting). "Rolling" here means bounded to the most recent segments, not
 * the whole call — keeps prompts small/fast/cheap as a call runs long
 * (PROJECT.md risk #6, cost monitoring), and Gemini Flash-Lite doesn't
 * need the whole history to answer an in-the-moment question well.
 *
 * Segment-count bounded rather than time-bounded — simpler, and a fixed
 * number of recent utterances is a good enough proxy for "recent" without
 * needing to reason about silence gaps.
 */
const aiSession = require('./aiSession');

const MAX_SEGMENTS = 40;

function getWindow(roomId) {
  return aiSession.getTranscript(roomId).slice(-MAX_SEGMENTS);
}

/** Formatted as `Speaker: text` lines, the shape Gemini gets in the prompt. */
function formatWindow(roomId) {
  const window = getWindow(roomId);
  if (window.length === 0) return '(no conversation captured yet)';
  return window.map((segment) => `${segment.displayName}: ${segment.text}`).join('\n');
}

module.exports = { getWindow, formatWindow, MAX_SEGMENTS };
